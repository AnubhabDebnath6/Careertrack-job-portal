import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="panel center">
      <h1>404</h1>
      <p>The page you are looking for does not exist.</p>
      <Link to="/" className="btn primary">Back to jobs</Link>
    </div>
  );
}
